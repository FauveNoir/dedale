#!/usr/bin/python3

listOfSybologies={}
listOfKeybindings={}
editorCommand="xdg-open"
#CONFIG_DIR=None
CONFIG_DIR = {"path": None}
